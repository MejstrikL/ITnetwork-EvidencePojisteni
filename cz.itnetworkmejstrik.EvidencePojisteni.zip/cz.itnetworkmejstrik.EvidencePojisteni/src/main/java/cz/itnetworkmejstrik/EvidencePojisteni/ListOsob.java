package cz.itnetworkmejstrik.EvidencePojisteni;

import java.util.ArrayList;
import java.util.Scanner;

public class ListOsob {
	private ArrayList<Pojisteny> osoby;
	private Scanner sc = new Scanner(System.in);
	
	public ListOsob() {
		osoby = new ArrayList<Pojisteny>();
	}
	
	public void pridejPojisteneho() {
		System.out.println("Zadejte jmeno pojisteneho:");
		String jmeno = sc.nextLine();
		System.out.println("Zadejte prijmeni:");
		String prijmeni = sc.nextLine();
		System.out.println("Zadejte telefonni cislo:");
		int telefonniCislo = Integer.parseInt(sc.nextLine());
		System.out.println("Zadejte vek:");
		int vek = Integer.parseInt(sc.nextLine());
		
		osoby.add(new Pojisteny(jmeno, prijmeni, vek, telefonniCislo));
	}
	public void vypisPojistene() {
		for (int i = 0; i < osoby.size(); i++) {
            System.out.println(osoby.get(i));
        }
	}
	public void najdiPojisteneho() {
		System.out.print("Zadejte jmeno: ");
        String jmeno = sc.nextLine();
        System.out.print("Zadejte prijmeni: ");
        String prijmeni = sc.nextLine();

        boolean nalezen = false;
        for (Pojisteny pojisteny : osoby) {
            if (pojisteny.getJmeno().equals(jmeno) && pojisteny.getPrijmeni().equals(prijmeni)) {
                System.out.println(pojisteny);
                nalezen = true;
                break;
            }
        }
        if (!nalezen) {
            System.out.println("Pojisteny nebyl nalezen!");
        }
	}
}
