package cz.itnetworkmejstrik.EvidencePojisteni;

import java.util.Scanner;

public class Main {
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		ListOsob listOsob = new ListOsob();
		
		String volbaAkce = "";
		while (!volbaAkce.equals("4")) {
			System.out.println("------------------------");
			System.out.println("Evidence pojistenych");
			System.out.println("------------------------");
			System.out.println("\nVyberte si akci:");
			System.out.println("1 - Pridat noveho pojisteneho");
			System.out.println("2 - Vypsat vsechny pojistene");
			System.out.println("3 - Vyhledat pojisteneho");
			System.out.println("4 - Konec");
			
			volbaAkce = sc.nextLine();
			switch (volbaAkce) {
			case "1":
				listOsob.pridejPojisteneho();
				System.out.println("Osoba byla pridana.");
				break;
			case "2":
				listOsob.vypisPojistene();
				break;
			case "3":
				listOsob.najdiPojisteneho();
				break;
			case "4":
				System.out.println("Aplikace bude ukoncena.");
				break;
			default:
				System.out.println("Byla zadana neplatna hodnota!");
				break;
			}
			System.out.println("Pokracujte stisknutim libovolne klavesy...");
			try
		    {
		        System.in.read();
		    }  
		    catch(Exception e)
		    {}
		}
	}

}
