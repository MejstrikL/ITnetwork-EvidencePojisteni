package cz.itnetworkmejstrik.EvidencePojisteni;

public class Pojisteny {
	private String jmeno;
	private String prijmeni;
	private int vek;
	private int telefonniCislo;
	
	public Pojisteny(String jmeno, String prijmeni, int vek, int telefonniCislo) {
		this.jmeno = jmeno;
		this.prijmeni = prijmeni;
		this.vek = vek;
		this.telefonniCislo = telefonniCislo;
	}
	
	public String getJmeno() {
		return jmeno;
	}
	public String getPrijmeni() {
		return prijmeni;
	}
	public int getVek() {
		return vek;
	}
	public int getTelefonniCislo() {
		return telefonniCislo;
	}
	
	public void setJmeno(String jmeno) {
		this.jmeno = jmeno;
	}
	public void setPrijmeni(String prijmeni) {
		this.prijmeni = prijmeni;
	}
	public void setVek(int vek) {
		this.vek = vek;
	}
	public void setTelefonniCislo(int telefonniCislo) {
		this.telefonniCislo = telefonniCislo;
	}
	
    @Override
    public String toString() {
        return "Jmeno: " + jmeno + ", Prijmeni: " + prijmeni + ", Vek: " + vek + ", Telefonni cislo: " + telefonniCislo;
    }
}
